from __future__ import division
import sys
reload(sys)
sys.setdefaultencoding='utf-8'
import string

training_pos = {}   #dictionary of positive training file
training_neg = {}   #dictionary of negative training file
pos_words=[]
np=0
number_pos_lines=0  #number of lines in positive training file
with open("hotelPosT-train.txt") as f:
    for line in f: 
        number_pos_lines+=1 
        import re
        pattern = re.compile("^(ID)")
        for word in line.split():
            if not pattern.match(word):
                word=word.lower()
                pos_words.append(filter(str.isalnum, word))
                np+=1

neg_words=[]
nn=0
number_neg_lines=0  #number of lines in negative training file
with open("hotelNegT-train.txt") as f:
    for line in f:  
        number_neg_lines+=1
        import re
        pattern = re.compile("^(ID)")
        for word in line.split():
            if not pattern.match(word):
                word=word.lower()
                neg_words.append(filter(str.isalnum, word))
                nn+=1

from collections import defaultdict
def count_words_list(list_words):
    return dict((x,list_words.count(x)) for x in set(list_words))
   
neg_word_count_dict=count_words_list(neg_words)
pos_word_count_dict=count_words_list(pos_words)

prior_pos=number_pos_lines/(number_pos_lines+number_neg_lines)
prior_neg=number_neg_lines/(number_neg_lines+number_pos_lines)

neg_likelihood={}
pos_likelihood={}

neg_den={}
for key in neg_word_count_dict:
    pc=0
    for key2 in pos_word_count_dict:
        if key2==key:
            pc=pos_word_count_dict[key2]
        else:
            pc=0
    neg_den[key]=neg_word_count_dict[key]+pc+nn
for key in neg_word_count_dict:
    neg_likelihood[key]=((neg_word_count_dict[key]+1)/neg_den[key])

pos_den={}
for key in pos_word_count_dict:
    nc=0
    for key2 in neg_word_count_dict:
        if key2==key:
            nc=neg_word_count_dict[key2]
        else:
            nc=0
    pos_den[key]=pos_word_count_dict[key]+nc+np
for key in pos_word_count_dict:
    pos_likelihood[key]=((pos_word_count_dict[key]+1)/pos_den[key])

#TESTING PHASE

test_words=[]
with open("test.txt") as f:
    f2=open("muruganandan-tarunianand-assign3-out.txt", "w")
    for line in f:  
        import re
        pos_prod=prior_pos
        neg_prod=prior_neg
        pattern = re.compile("^(ID)")
        for word in line.split():
            if not pattern.match(word):
                word=word.lower()
                word=(filter(str.isalnum, word))
                for key in pos_likelihood:
                    if key == word:
                        pos_prod*=pos_likelihood[key]
                for key in neg_likelihood:
                    if key == word:
                        neg_prod*=neg_likelihood[key]
        if pos_prod<neg_prod:
            f2.write(line[:7]+" POS\n")
        else:
            f2.write(line[:7]+" NEG\n")

